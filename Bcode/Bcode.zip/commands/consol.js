const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('consol')
        .setDescription('Console related commands')
        .addSubcommand(subcommand =>
            subcommand
                .setName('tell')
                .setDescription('Send a message to the host via console')
                .addStringOption(option =>
                    option.setName('host')
                        .setDescription('Host to send the message to')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Message to send')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('runtime')
                .setDescription('Show how long the bot has been online'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'tell') {
            const host = interaction.options.getString('host');
            const message = interaction.options.getString('message');

            console.log(`[Tell Command] Host: ${host} - Message: ${message}`);

            await interaction.reply({ content: `Message sent to host: ${host}`, ephemeral: true });
        } else if (subcommand === 'runtime') {
            const uptimeSeconds = Math.floor(process.uptime());
            const timestamp = `<t:${Math.floor((Date.now() / 1000) - uptimeSeconds)}:R>`;
            await interaction.reply({ content: `Bot has been online for ${timestamp}`, ephemeral: true });
        }
    }
};
